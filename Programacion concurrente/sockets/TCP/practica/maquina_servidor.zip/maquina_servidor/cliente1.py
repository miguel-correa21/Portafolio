import socket
import os
from archivos_x_socket import archivo
from archivos_x_socket import utilidades

HOST = '192.168.43.89'
HOST_SERVIDOR2 = '192.168.43.235'
HOST_SERVIDOR3 = '192.168.43.247'
PORT = 8001
PORT_SERVIDOR2 = 8002
PORT_SERVIDOR3 = 8003
BUFFER = 1024
actualizar = False

def menu():
    #os.system("clear")
    print("""
            1) Crear/Subir un Nuevo archivo
            2) Eliminar  archivo
            3) Actualizar archivo
            4) Mostrar Contenido de un archivo
            5) Listar
            """)

def listar_archivos():
    print("\t Archivo en este directorio")
    directorio = os.listdir("./")
    for archivo in directorio:
        print(f"\t>>{archivo}")
    

def avisar(accion,conexion,nombre_archivo):
    global actualizar
    listar_archivos()
    '''
    acciones:
        1:agregar archivo
        2:eliminar archivo
        3:actualizar archivo
        4:mostrar contenido de un archivo 
    '''
    if accion == 1:
        conexion.send(bytes('nuevo','utf-8'))
        respuesta = conexion.recv(BUFFER).decode('utf-8')
        if str(respuesta) != ' ':
            if  archivo.nuevo_archivo(nombre_archivo):
                print(f"Archivo:{nombre_archivo} creado exitosamente")
                print("enviando archivo...")
                if archivo.mandar_archivo(conexion,nombre_archivo):
                    print("Archivo mandado Correctamente")
#                    input("Presione 'Enter' para continuar...")

    elif accion == 2:
        conexion.send(bytes('eliminar','utf-8'))
        respuesta = conexion.recv(BUFFER).decode('utf-8')
        if str(respuesta) != ' ':
            conexion.send(bytes(nombre_archivo,'utf-8'))
            if archivo.eliminar_archivo(nombre_archivo):
                print(f"Archivo:{nombre_archivo} ha sido eliminado")
            else:
                print(f"no se puede eliminar el archivo:{nombre_archivo}")

    elif accion == 3:
        if not '.txt' in nombre_archivo:
            print(f"El formato del archivo no permite la actualización del archivo : {nombre_archivo}")
            return 
        conexion.send(bytes('actualizar','utf-8'))
        respuesta = conexion.recv(BUFFER).decode('utf-8')
        if str(respuesta) != ' ':
            if actualizar:
                archivo.mandar_archivo(conexion,nombre_archivo,"actualizar")
                actualizar = False 
                
            elif archivo.actualizar_archivo(nombre_archivo):
                print(f"Archivo:{nombre_archivo} ha sido actualizado")
                archivo.mandar_archivo(conexion,nombre_archivo,"actualizar")
                actualizar = True

            else:
                print(f"no se puede actualizar el archivo:{nombre_archivo}")
            #input("Presione 'Enter' para continuar...")
    
    elif accion == 4:
        if not ".txt" in nombre_archivo:
            print("Solo se muestran archivos de texto")
            return

        ruta = './' + nombre_archivo
        if os.path.isfile(ruta):
           os.system(f"cat {nombre_archivo}") 
           input("Oprima Enter para continuar...")
        else:
            print(f"el archivo{nombre_archivo} no existe")
            #input("Oprima Enter para continuar...")
    
    elif accion == 5:
        listar_archivos()


with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as servidor2:
    servidor2.connect((HOST_SERVIDOR2,PORT_SERVIDOR2))
    #segundo servidor
    servidor3 = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    servidor3.connect((HOST_SERVIDOR3,PORT_SERVIDOR3))
    while True:
        menu()
        accion = int(input("Ingresa la acción que se quiere Realizar:"))
        listar_archivos()
        nombre_archivo = input("Ingrese el nombre del archivo a /crear/eliminar/actualizar: ")
        avisar(accion,servidor2,nombre_archivo)
        listo = servidor2.recv(BUFFER).decode('utf-8')
        print(str(listo))
       # if str(listo) == 'listo':
        print("se proceso correctamente")
        avisar(accion,servidor3,nombre_archivo)
        listo = servidor3.recv(BUFFER).decode('utf-8')
        if str(listo) == 'listo':
            print("se procesarón correctamente todas las peticiones")
    
    servidor3.close()

