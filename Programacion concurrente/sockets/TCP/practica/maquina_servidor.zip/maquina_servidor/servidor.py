import socket
import os
import threading
from archivos_x_socket import archivo
from archivos_x_socket import utilidades

 #localhost
HOST = '192.168.43.89'
HOST_SERVIDOR2 = '192.168.43.235'
HOST_SERVIDOR3 = '192.168.43.247'
PORT = 8001 #puerto desde el que se escucha
            #puertos no privilegiados > 1023
PORT_SERVIDOR2 = 8002
PORT_SERVIDOR3 = 8003
BUFFER = 1024

def distribuir_accion(accion,nombre_archivo):
    if accion == 'nuevo':
        accion_cliente = 1
    elif accion == 'eliminar':
        accion_cliente = 2
    elif accion == 'actualizar':
        accion_cliente = 3
    #semaforo = threading.Semaphore()
    #semaforo.acquire()
    hilo1 = threading.Thread(target=cliente,
        args=(PORT_SERVIDOR2,HOST_SERVIDOR2,accion_cliente,nombre_archivo))
    hilo1.start()
    hilo1.join()
    #semaforo.release()
    #semaforo.acquire()
    hilo2 = threading.Thread(target=cliente,
        args=(PORT_SERVIDOR3,HOST_SERVIDOR3,accion_cliente,nombre_archivo))
    hilo2.start()
    hilo2.join()
    #semaforo.release()
    
def cliente(*args):
    puerto = args[0]
    host = args[1]
    accion = args[2]
    nombre_archivo = args[3]
    print(f"Mandando a petición al servidor con puerto {puerto}")
    with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as servidor:
        servidor.connect((host,puerto))
        print(f"se manda el archivo {nombre_archivo} accion:{accion} \
            servidor:{servidor}")
        utilidades.avisar(accion,servidor,nombre_archivo)

'''
def mandar_actualizacion_x_cliente(*args):
    puerto = args[0]
    host = args[1]
    print("Procesando petición de actualización")
    print("Enviando a ", host, "con puerto", puerto)
    with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as conexion:
        conexion.connect((host,puerto))
        tam = archivo.contar_archivos()
        conexion.send(bytes(str(tam)),'utf-8')
        print(f"se mandan {tam} archivos")
        respuesta = conexion.recv(BUFFER).decode('utf-8')
        print(respuesta)
        archivo.refrescar(conexion)

def actualizar_clientes(conexion):
    hilo1 = threading.Thread(target=mandar_actualizacion_x_cliente,
        args=(PORT_SERVIDOR2,HOST_SERVIDOR2))
    hilo1.start()
    hilo1.join()
    conexion.send(bytes('ok','utf-8'))
    #semaforo.release()
    #semaforo.acquire()
   # hilo2 = threading.Thread(target=mandar_actualizacion_x_cliente,
   #     args=(PORT_SERVIDOR3,HOST_SERVIDOR3))
   # hilo2.start()
   # hilo2.join()
   '''


def tarea_servidor(*args):
    conexion = args[0]
    dir = args[1]
    print("Se conecto con ", dir)
   # actualizar = conexion.recv(BUFFER).decode('utf-8')
   # if str(actualizar) == "refrescar":
   #     actualizar_clientes(conexion)
   # else:
   #     print(actualizar)
    while True:
        accion = str(conexion.recv(BUFFER).decode('utf-8')) 
        nombre_archivo = utilidades.realizar_accion(accion,conexion) 
        if nombre_archivo != ' ':
            distribuir_accion(accion,nombre_archivo)
        else:
            print("No se puede atender a los clientes")
        print("Se termino de procesar la petición\nEn espera de otra...")

##creamos el socket con la configuración especificada
#utilizamos with para no tener que utilizar close
with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as ser:
    ser.bind((HOST,PORT))
    ser.listen()
    while True:
        conexion,dir = ser.accept()
        threading.Thread(target=tarea_servidor,args=(conexion,dir)).start()


