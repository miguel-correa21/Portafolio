from archivos_x_socket import archivo
import os

BUFFER  = 1024

def menu():
    os.system("clear")
    print("""
            1) Crear un Nuevo archivo
            2) Eliminar  archivo
            3) Actualizar archivo
            4) Mostrar Contenido de un archivo
            """)

def listar_archivos():
    print("\t Archivo en este directorio")
    directorio = os.listdir("./")
    for archivo in directorio:
        print(f"\t>>{archivo}")
    

def avisar(accion,conexion,nombre_archivo):
    '''
    acciones:
        1:agregar archivo
        2:eliminar archivo
        3:actualizar archivo
        4:mostrar contenido de un archivo 
    '''
    if accion == 1:
        conexion.send(bytes('nuevo','utf-8'))
        respuesta = conexion.recv(BUFFER).decode('utf-8')
        if str(respuesta) == 'ok':
            print("enviando archivo...")
            archivo.mandar_archivo(conexion,nombre_archivo)
            #if  archivo.nuevo_archivo(nombre_archivo):
            #    print(f"Archivo:{nombre_archivo} creado exitosamente")

    elif accion == 2:
        conexion.send(bytes('eliminar','utf-8'))
        respuesta = conexion.recv(BUFFER).decode('utf-8')
        if str(respuesta) =='ok':
            conexion.send(bytes(nombre_archivo,'utf-8'))
            if archivo.eliminar_archivo(nombre_archivo):
                print(f"Archivo:{nombre_archivo} ha sido eliminado")
                listar_archivos()
            else:
                print(f"no se puede eliminar el archivo:{nombre_archivo}")

    elif accion == 3:
        conexion.send(bytes('actualizar','utf-8'))
        respuesta = conexion.recv(BUFFER).decode('utf-8')
        if str(respuesta) == 'ok':
            archivo.mandar_archivo(conexion,nombre_archivo,"actualizar")
            print("actualizando archivo")
            #if archivo.actualizar_archivo(nombre_archivo):
            #    print(f"Archivo:{nombre_archivo} ha sido eliminado")
            #else:
            #    print(f"no se puede actualizar el archivo:{nombre_archivo}")

    elif accion == 4:
        ruta = './' + nombre_archivo
        if not ".txt" in nombre_archivo:
            ruta += '.txt'
        if os.path.isfile(ruta):
           os.system(f"cat {nombre_archivo}") 
           input("Oprima Enter para continuar...")
        else:
            print(f"el archivo{nombre_archivo} no existe")
            input("Oprima Enter para continuar...")


def realizar_accion(accion,conexion):
    os.system("clear")
    listar_archivos()
    nombre_archivo = ' '
    if accion == 'nuevo':
        conexion.send(bytes('ok','utf-8'))
        print("Recibiendo nuevo archivo...")
        nombre_archivo = archivo.recibir_archivo(conexion,BUFFER)
        if(nombre_archivo != ' '):
            print("se recibio el archivo exitosamente")
            print("contenido del archivo: ")
            os.system(f"cat {nombre_archivo}")
        else:
            print("No se recibio el archivo")
        
    elif accion == 'eliminar':
        print("Eliminando archivo...")
        conexion.send(bytes('ok','utf-8'))
        nombre_archivo = str(conexion.recv(BUFFER).decode('utf-8'))
        if archivo.eliminar_archivo(nombre_archivo):
            print(f"Archivo:{nombre_archivo} se elimino correctamente")
            listar_archivos()
        else:
            print("No se pudo eliminar el archivo")

    elif accion == 'actualizar':
        print("Actualizando archivo")
        conexion.send(bytes('ok','utf-8'))
        nombre_archivo = archivo.recibir_archivo(conexion,BUFFER,"actualizar")
        if(nombre_archivo != ' '):
            print("se actualizo el archivo exitosamente")
            print("nuevo contenido del archivo: ")
            os.system(f"cat {nombre_archivo}")
        else:
            print("No se pudo actualizar el archivo")
    
    return nombre_archivo